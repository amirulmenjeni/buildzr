"""PlantUML sink for exporting workspaces to PlantUML diagrams."""

import os
import re
import shutil
from dataclasses import dataclass
from typing import Optional, Literal, Any
from buildzr.models.models import Workspace
from buildzr.sinks.interfaces import Sink


class PlantUmlRenderError(RuntimeError):
    """Raised when PlantUML cannot render a diagram to an image.

    This covers a missing Graphviz ``dot`` executable as well as PlantUML
    producing an error image (e.g. for a syntax error) instead of a diagram.
    """


# Layout engine used by PlantUML: 'dot' needs Graphviz, 'smetana' is pure Java.
PlantUmlLayout = Literal["dot", "smetana"]

_PLANTUML_LAYOUTS = ("dot", "smetana")

_PLANTUML_ERROR_BANNERS = (
    "Dot executable does not exist",
    "Cannot find Graphviz",
    "Syntax Error?",
)


@dataclass
class PlantUmlSinkConfig:
    """
    Configuration for PlantUML export.

    Attributes:
        path: Output directory path where .puml files will be written
        format: Output format - 'puml' for text files, 'svg'/'png' for rendered images
        structurizr_export_jar_path: Optional custom path to structurizr-export JAR.
            If not provided, uses the bundled JAR.
        layout: PlantUML layout engine. 'dot' (default) uses Graphviz for svg/png
            rendering. 'smetana' adds ``!pragma layout smetana`` to every diagram
            so PlantUML lays it out in pure Java, without Graphviz (layout quality
            is somewhat worse). Applies to the written .puml files too.
    """

    path: str
    format: Literal["puml", "svg", "png"] = "puml"
    structurizr_export_jar_path: Optional[str] = None
    layout: PlantUmlLayout = "dot"


class PlantUmlSink(Sink[PlantUmlSinkConfig]):
    """
    Sink for exporting workspace views to PlantUML format.

    This sink uses the official structurizr-export Java library via JPype
    to generate PlantUML diagrams from workspace views.

    Examples:
        >>> from buildzr.sinks.plantuml_sink import PlantUmlSink, PlantUmlSinkConfig
        >>> sink = PlantUmlSink()
        >>> config = PlantUmlSinkConfig(path='output/diagrams')
        >>> sink.write(workspace, config)
    """

    def export_to_dict(self, workspace: Workspace) -> dict[str, str]:
        """
        Export workspace views to PlantUML strings without writing files.

        Args:
            workspace: The workspace to export

        Returns:
            Dictionary mapping view keys to PlantUML source strings.

        Raises:
            ImportError: If jpype1 is not installed (install with: pip install buildzr[export-plantuml])
            FileNotFoundError: If structurizr-export JAR cannot be found
        """
        try:
            import jpype  # type: ignore
        except ImportError as e:
            raise ImportError(
                "jpype1 is required for PlantUML export. "
                "Install with: pip install buildzr[export-plantuml]"
            ) from e

        # Initialize JVM with default config
        self._ensure_jvm_started(PlantUmlSinkConfig(path=""))

        # Enable C4-PlantUML tags for icon/sprite support
        self._ensure_c4plantuml_tags_enabled(workspace)

        # Convert workspace to Java
        from buildzr.exporters.workspace_converter import WorkspaceConverter
        converter = WorkspaceConverter()
        java_workspace = converter.to_java(workspace)

        # Export and return
        return self._export_workspace(java_workspace)

    def render_to_svg_dict(
        self,
        workspace: Workspace,
        layout: PlantUmlLayout = "dot",
    ) -> dict[str, str]:
        """
        Export workspace views and render to SVG strings.

        Args:
            workspace: The workspace to export
            layout: PlantUML layout engine, 'dot' (needs Graphviz) or 'smetana'
                (pure Java, no Graphviz required).

        Returns:
            Dictionary mapping view keys to SVG content strings.

        Raises:
            ImportError: If jpype1 is not installed (install with: pip install buildzr[export-plantuml])
            FileNotFoundError: If structurizr-export JAR cannot be found
            PlantUmlRenderError: If layout is 'dot' and Graphviz (``dot``) is not
                available, or PlantUML fails to render a view.
            ValueError: If layout is not 'dot' or 'smetana'.
        """
        self._validate_layout(layout)

        # Check for jpype first, so a missing jpype1 is reported as ImportError
        # (with install instructions) even when Graphviz is also missing.
        try:
            import jpype  # type: ignore  # noqa: F401
        except ImportError as e:
            raise ImportError(
                "jpype1 is required for PlantUML export. "
                "Install with: pip install buildzr[export-plantuml]"
            ) from e

        if layout == "dot":
            self._ensure_graphviz_available()

        # First get PlantUML strings
        diagrams = self.export_to_dict(workspace)
        if layout == "smetana":
            diagrams = {k: self._apply_layout(v, layout) for k, v in diagrams.items()}

        # Render each to SVG
        result: dict[str, str] = {}
        for view_key, puml_content in diagrams.items():
            svg_bytes = self._render_to_bytes(puml_content, "svg", view_key)
            # Apply SVG cleanup to remove placeholder characters
            svg_bytes = self._clean_svg_legend(svg_bytes)
            result[view_key] = svg_bytes.decode('utf-8')

        return result

    @staticmethod
    def _validate_layout(layout: str) -> None:
        """Raise ValueError if layout is not a supported layout engine."""
        if layout not in _PLANTUML_LAYOUTS:
            raise ValueError(
                f"Unsupported layout: {layout!r}. Use one of: 'dot', 'smetana'"
            )

    @staticmethod
    def _apply_layout(puml_content: str, layout: PlantUmlLayout) -> str:
        """
        Apply the layout engine to a PlantUML diagram.

        For 'smetana', inserts ``!pragma layout smetana`` directly after the first
        ``@startuml`` line. For 'dot' the content is returned unchanged.

        Args:
            puml_content: PlantUML source string
            layout: PlantUML layout engine

        Returns:
            PlantUML source with the layout pragma applied.
        """
        if layout != "smetana":
            return puml_content
        lines = puml_content.split('\n')
        for i, line in enumerate(lines):
            if line.strip().startswith('@startuml'):
                lines.insert(i + 1, '!pragma layout smetana')
                break
        return '\n'.join(lines)

    @staticmethod
    def _graphviz_missing_message(detail: str) -> str:
        """Build the error message for a missing Graphviz installation."""
        return (
            f"Graphviz is required to render svg/png diagrams, but {detail}. "
            "Install Graphviz (https://graphviz.org/download/) and make sure the "
            "`dot` executable is on your PATH, or point the GRAPHVIZ_DOT "
            "environment variable at it, or render without Graphviz using "
            "layout='smetana'."
        )

    @classmethod
    def _ensure_graphviz_available(cls) -> None:
        """
        Check that the Graphviz ``dot`` executable can be found.

        Mirrors PlantUML's lookup: ``GRAPHVIZ_DOT`` if set, otherwise ``dot`` on PATH.

        Raises:
            PlantUmlRenderError: If the ``dot`` executable cannot be found.
        """
        dot_env = os.environ.get("GRAPHVIZ_DOT")
        if dot_env:
            if not os.path.isfile(dot_env):
                raise PlantUmlRenderError(cls._graphviz_missing_message(
                    f"GRAPHVIZ_DOT points to '{dot_env}', which does not exist"
                ))
        elif shutil.which("dot") is None:
            raise PlantUmlRenderError(cls._graphviz_missing_message(
                "the `dot` executable was not found"
            ))

    def _render_to_bytes(
        self,
        puml_content: str,
        format: str,
        view_key: Optional[str] = None,
    ) -> bytes:
        """
        Render PlantUML content to image bytes.

        Args:
            puml_content: PlantUML source string
            format: Output format ('svg' or 'png')
            view_key: Optional view key, used in error messages.

        Returns:
            Image content as bytes.

        Raises:
            PlantUmlRenderError: If PlantUML produced an error image instead of a diagram.
        """
        try:
            from net.sourceforge.plantuml import SourceStringReader, FileFormatOption, FileFormat  # type: ignore
            from java.io import ByteArrayOutputStream  # type: ignore
        except ImportError as e:
            raise ImportError(
                "PlantUML rendering not available. "
                "Ensure the PlantUML JAR is in the classpath."
            ) from e

        reader = SourceStringReader(puml_content)
        file_format = FileFormat.SVG if format == 'svg' else FileFormat.PNG

        # Use Java ByteArrayOutputStream for compatibility
        output = ByteArrayOutputStream()
        description = reader.outputImage(output, FileFormatOption(file_format))
        image_bytes = bytes(output.toByteArray())

        error: Optional[str] = None
        if description is not None and str(description.getDescription()) == "(Error)":
            error = "PlantUML reported an error (syntax error in the diagram source)"
        elif format == 'svg':
            text = image_bytes.decode('utf-8', errors='replace')
            for banner in _PLANTUML_ERROR_BANNERS:
                if banner in text:
                    error = f"PlantUML rendered an error image ('{banner}')"
                    break
        if error is not None:
            where = f" for view '{view_key}'" if view_key else ""
            raise PlantUmlRenderError(f"Failed to render {format}{where}: {error}.")

        return image_bytes

    def write(self, workspace: Workspace, config: Optional[PlantUmlSinkConfig] = None) -> None:
        """
        Export workspace views to PlantUML files.

        Args:
            workspace: The workspace to export
            config: Optional configuration. If None, uses default (puml format, current directory)

        Raises:
            ImportError: If jpype1 is not installed (install with: pip install buildzr[export-plantuml])
            FileNotFoundError: If structurizr-export JAR cannot be found
            PlantUmlRenderError: If svg/png output is requested with layout 'dot'
                and Graphviz (``dot``) is not available, or PlantUML fails to render
                a view. A missing Graphviz is reported before any file is written.
            ValueError: If config.layout is not 'dot' or 'smetana'.
            RuntimeError: If JVM initialization or export fails
        """
        if config is None:
            config = PlantUmlSinkConfig(path=os.curdir)

        # Check for jpype first
        try:
            import jpype
        except ImportError as e:
            raise ImportError(
                "jpype1 is required for PlantUML export. "
                "Install with: pip install buildzr[export-plantuml]"
            ) from e

        self._validate_layout(config.layout)
        if config.format in ('svg', 'png') and config.layout == 'dot':
            self._ensure_graphviz_available()

        # Initialize JVM if needed
        self._ensure_jvm_started(config)

        # Enable C4-PlantUML tags for icon/sprite support
        self._ensure_c4plantuml_tags_enabled(workspace)

        # Phase 2: Convert workspace to Java
        from buildzr.exporters.workspace_converter import WorkspaceConverter
        converter = WorkspaceConverter()
        java_workspace = converter.to_java(workspace)

        # Phase 3: Export using Java exporter
        diagrams = self._export_workspace(java_workspace)
        if config.layout == 'smetana':
            diagrams = {k: self._apply_layout(v, config.layout) for k, v in diagrams.items()}

        # Phase 4: Write files and render
        self._write_diagrams(diagrams, config)

    def _ensure_jvm_started(self, config: PlantUmlSinkConfig) -> None:
        """
        Ensure JVM is started with the structurizr-export and dependency JARs.

        Args:
            config: Configuration containing optional custom JAR path

        Raises:
            FileNotFoundError: If JARs cannot be found
        """
        import jpype
        from buildzr.exporters.jar_locator import get_bundled_jar_paths

        if jpype.isJVMStarted():
            return  # JVM already running

        # Determine JAR paths
        if config.structurizr_export_jar_path:
            # Custom JAR path provided - use only that
            jar_paths = [config.structurizr_export_jar_path]
            if not os.path.exists(jar_paths[0]):
                raise FileNotFoundError(
                    f"structurizr-export JAR not found at {jar_paths[0]}"
                )
        else:
            # Use bundled JARs (export + dependencies)
            jar_paths = get_bundled_jar_paths()  # Raises if not found

        # Start JVM with JARs in classpath
        jpype.startJVM(classpath=jar_paths)
        print(f"JVM started with JARs: {', '.join(jar_paths)}")

    def _ensure_c4plantuml_tags_enabled(self, workspace: Workspace) -> None:
        """
        Ensure the c4plantuml.tags property is set to enable icon/sprite support.

        The C4PlantUML exporter only outputs AddElementTag() with sprites when
        the c4plantuml.tags property is set to "true". This method ensures that
        property is set when the workspace has element styles with icons.

        Args:
            workspace: The workspace to configure
        """
        from buildzr.models.models import Configuration

        if not workspace.views:
            return

        # Ensure configuration exists
        if not workspace.views.configuration:
            workspace.views.configuration = Configuration()

        config = workspace.views.configuration

        # Ensure properties dict exists
        if not config.properties:
            config.properties = {}

        # Enable c4plantuml.tags if not explicitly set
        if 'c4plantuml.tags' not in config.properties:
            config.properties['c4plantuml.tags'] = 'true'

    @staticmethod
    def _filter_empty_sprite_tags(puml_content: str) -> str:
        """
        Filter out tag statements that would show empty placeholder characters in legends.

        This prevents the legend from showing empty placeholder characters (U+25AF ▯)
        for tags that don't have associated icons/sprites.

        Filters out:
        - AddElementTag with empty $sprite="" parameters
        - AddBoundaryTag entries (boundaries don't have icons, only show ▯)

        Args:
            puml_content: The PlantUML diagram content

        Returns:
            Filtered PlantUML content with problematic tag definitions removed
        """
        # Pattern matches AddElementTag lines where $sprite="" (empty sprite)
        empty_sprite_pattern = r'^AddElementTag\([^)]*\$sprite=["\']["\'][^)]*\)\s*$'

        # Pattern matches AddBoundaryTag lines (boundaries show ▯ without icons)
        boundary_tag_pattern = r'^AddBoundaryTag\('

        # Split content into lines, filter, and rejoin
        lines = puml_content.split('\n')
        filtered_lines = []
        for line in lines:
            # Skip lines with empty sprites
            if re.match(empty_sprite_pattern, line):
                continue
            # Skip boundary tag lines (they only show color swatches, no icons)
            if re.match(boundary_tag_pattern, line):
                continue
            filtered_lines.append(line)

        return '\n'.join(filtered_lines)

    def _export_workspace(self, java_workspace: Any) -> dict[str, str]:
        """
        Export all views in Java workspace to PlantUML diagrams.

        Args:
            java_workspace: Java com.structurizr.Workspace object

        Returns:
            Dictionary mapping view keys to PlantUML diagram content
        """
        from com.structurizr.export.plantuml import C4PlantUMLExporter  # type: ignore

        exporter = C4PlantUMLExporter()
        diagrams = {}

        # Get all views from workspace
        views = java_workspace.getViews()

        # Export system landscape views
        for view in views.getSystemLandscapeViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        # Export system context views
        for view in views.getSystemContextViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        # Export container views
        for view in views.getContainerViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        # Export component views
        for view in views.getComponentViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        # Export deployment views
        for view in views.getDeploymentViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        # Export dynamic views
        for view in views.getDynamicViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        # Export custom views
        for view in views.getCustomViews():
            diagram = exporter.export(view)
            diagrams[str(view.getKey())] = self._filter_empty_sprite_tags(str(diagram.getDefinition()))

        return diagrams

    def _write_diagrams(self, diagrams: dict[str, str], config: PlantUmlSinkConfig) -> None:
        """
        Write PlantUML diagrams to files.

        Args:
            diagrams: Dictionary mapping view keys to PlantUML content
            config: Export configuration
        """
        # Create output directory if needed
        os.makedirs(config.path, exist_ok=True)

        for view_key, puml_content in diagrams.items():
            # Write .puml file
            puml_path = os.path.join(config.path, f"{view_key}.puml")
            with open(puml_path, 'w', encoding='utf-8') as f:
                f.write(puml_content)
            print(f"Exported: {puml_path}")

            # Render to image if requested
            if config.format in ['svg', 'png']:
                self._render_diagram(puml_path, config.format, view_key)

    def _render_diagram(self, puml_path: str, format: str, view_key: Optional[str] = None) -> None:
        """
        Render PlantUML diagram to image format.

        Args:
            puml_path: Path to .puml file
            format: Output format ('svg' or 'png')
            view_key: Optional view key, used in error messages.
        """
        # Read PlantUML content
        with open(puml_path, 'r', encoding='utf-8') as f:
            puml_content = f.read()

        # Render to bytes using our helper method
        try:
            image_bytes = self._render_to_bytes(puml_content, format, view_key)
        except ImportError:
            print(f"Warning: PlantUML rendering not available. Skipping {format} rendering.")
            return

        # Write output
        output_path = puml_path.rsplit('.', 1)[0] + f'.{format}'

        # Post-process SVG to remove empty placeholder characters
        if format == 'svg':
            image_bytes = self._clean_svg_legend(image_bytes)

        with open(output_path, 'wb') as f:
            f.write(image_bytes)

        print(f"Rendered: {output_path}")

    @staticmethod
    def _clean_svg_legend(svg_bytes: bytes) -> bytes:
        """
        Remove empty placeholder characters (▯ U+25AF) from SVG legend entries.

        C4-PlantUML renders &#9647; as a color indicator in legends. This character
        may display as an empty box [] on some systems. This method removes it.

        Args:
            svg_bytes: Raw SVG content as bytes

        Returns:
            Cleaned SVG content with placeholder characters removed
        """
        svg_content = svg_bytes.decode('utf-8')

        # Remove &#9647; (decimal) and ▯ (literal) characters from the SVG
        svg_content = svg_content.replace('&#9647;', '')
        svg_content = svg_content.replace('\u25af', '')

        return svg_content.encode('utf-8')
