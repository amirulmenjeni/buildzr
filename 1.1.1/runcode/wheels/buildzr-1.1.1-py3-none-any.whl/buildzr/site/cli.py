"""The ``buildzr`` command: ``build``, ``export`` and ``serve``.

Every setting comes from a flag, then from ``buildzr.yaml`` (see :mod:`buildzr.site.config`), then from the
built-in default. Exit codes: 0 ok, 1 build, check or runtime failure, 2 usage or config error.
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import tempfile
import threading
from pathlib import Path
from typing import Any, Iterable, NoReturn, Optional

from buildzr.site import config as cfgmod
from buildzr.site import export_files, watch
from buildzr.site.api import normalise_origin, normalise_public_url
from buildzr.site.build import BuildError, BuildResult, Entry, build_all, plan, source_root
from buildzr.site.config import (
    DEFAULT_HOST,
    DEFAULT_OUT,
    DEFAULT_PORT,
    DEFAULT_WORKSPACES,
    PORT_MESSAGE,
    BuildSettings,
    Config,
    ConfigError,
)
from buildzr.site.example import ExampleError, stage as stage_example
from buildzr.site.serve import Catalog, holds_built_workspaces, serve


#: The output folder of ``buildzr export``.
DEFAULT_EXPORT_OUT = "export"


def _version() -> str:
    """The installed version from the package metadata, as in the wheel name; ``__about__`` without an install."""
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version("buildzr")
    except PackageNotFoundError:
        from buildzr.__about__ import VERSION
        return VERSION


class _Parser(argparse.ArgumentParser):
    def error(self, message: str) -> NoReturn:
        self.print_usage(sys.stderr)
        raise _Usage(message)


class _Usage(Exception):
    """A usage or configuration problem: printed as ``buildzr: error: ...``, exit 2."""


def _add_build_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("-w", "--workspaces", dest="workspace", metavar="PATH", default=None,
                   help="the Python file or folder that creates workspaces; it replaces workspaces: of buildzr.yaml, "
                        "which can also list several files and folders, each with its own build settings; the build: "
                        f"settings of the file still apply (default: workspaces: in buildzr.yaml, else "
                        f"{DEFAULT_WORKSPACES}/)")
    p.add_argument("--k", type=int, default=None, metavar="N",
                   help="room for a box that contains other boxes, in areas of an empty box; raise it if their insides "
                        "are too small to read, lower it for compact diagrams (default: build.k in buildzr.yaml, else 4)")
    p.add_argument("--text-color", choices=["wcag", "c4"], default=None,
                   help="text colour on boxes, wcag or c4 (default: build.text_color in buildzr.yaml, else wcag)")
    p.add_argument("--no-viewer", action="store_true",
                   help="write data only, without the viewer bundle (also for the entries of buildzr.yaml that set "
                        "viewer: true)")
    p.add_argument("-c", "--config", metavar="FILE", default=None,
                   help="config file (default: buildzr.yaml, searched from the current folder upward)")
    p.add_argument("-v", "--verbose", action="store_true",
                   help="also show the summary line of the step that runs each Python file")


def _parser() -> argparse.ArgumentParser:
    ap = _Parser(prog="buildzr", description="Build and serve buildzr workspaces.")
    ap.add_argument("--version", action="version", version=f"buildzr {_version()}",
                    help="show the installed buildzr version and exit")
    sub = ap.add_subparsers(dest="cmd", required=True, parser_class=_Parser)
    b = sub.add_parser("build", help="build every workspace of the workspaces folder")
    _add_build_args(b)
    b.add_argument("-o", "--out", metavar="DIR", default=None,
                   help=f"build output: one folder per workspace (default: build.out in buildzr.yaml, else {DEFAULT_OUT})")
    x = sub.add_parser("export", help="write the workspaces of a model file as JSON, PlantUML, SVG or PNG files",
                       description="Run a model file and write every workspace it creates (or the one you pick) "
                                   "as Structurizr JSON, PlantUML source, SVG or PNG files, one folder per workspace.")
    x.add_argument("file", metavar="FILE", help="the Python model file that creates the workspaces")
    x.add_argument("-f", "--format", action="append", choices=export_files.FORMATS, default=None, metavar="FORMAT",
                   help="json, plantuml, svg or png; repeat the option for several (default: json). plantuml, svg "
                        "and png need buildzr[export-plantuml] and Java; svg and png also need Graphviz, unless "
                        "--layout smetana")
    x.add_argument("-o", "--out", metavar="DIR", default=DEFAULT_EXPORT_OUT,
                   help=f"output folder; each workspace gets a subfolder (default: {DEFAULT_EXPORT_OUT})")
    x.add_argument("--workspace", metavar="NAME", default=None,
                   help="export only the workspace with this name (default: every workspace of the file)")
    x.add_argument("--index", type=int, default=None, metavar="N",
                   help="export only the N-th workspace the file creates, counting from 0; use it when two "
                        "workspaces share a name")
    x.add_argument("--layout", choices=export_files.LAYOUTS, default="dot",
                   help="PlantUML layout engine for plantuml, svg and png: dot (Graphviz) or smetana (no Graphviz, "
                        "rougher layout) (default: dot)")
    x.add_argument("--pretty", action="store_true", help="indent the JSON output")
    s = sub.add_parser("serve", help="build what is stale, then serve every workspace (read-only)")
    s.add_argument("path", nargs="?", default=None, metavar="PATH",
                   help="a workspaces folder or a .py file (built if stale, then the build output is served; it "
                        "replaces workspaces: of buildzr.yaml), or a folder of built workspaces (served as it is) "
                        "(default: workspaces: in buildzr.yaml, a path or a list, else workspaces/)")
    s.add_argument("--example", action="store_true",
                   help="serve the bundled example workspace instead of your own: nothing is built or written, and "
                        "buildzr.yaml is ignored (only --port, --host, --public-url and --cors-origin apply; "
                        "PATH, --no-build, --rebuild, -c and -v do not)")
    s.add_argument("--no-build", action="store_true", help="serve the build output as it is, without building")
    s.add_argument("--rebuild", action="store_true", help="build every workspace again, even the up-to-date ones")
    s.add_argument("--watch", action="store_true",
                   help="keep watching the model files and their _*.py helpers: rebuild what a change makes stale and "
                        "reload the open viewers; a rebuild that fails keeps the last good build served")
    s.add_argument("-c", "--config", metavar="FILE", default=None,
                   help="config file (default: buildzr.yaml, searched from the current folder upward)")
    s.add_argument("-v", "--verbose", action="store_true",
                   help="also show the summary line of the step that runs each Python file")
    s.add_argument("-p", "--port", type=int, default=None,
                   help=f"port, 1 to 65535 (default: serve.port in buildzr.yaml, else {DEFAULT_PORT})")
    s.add_argument("--host", default=None,
                   help=f"address to listen on (default: serve.host in buildzr.yaml, else {DEFAULT_HOST}); "
                        "use 0.0.0.0 explicitly to share")
    s.add_argument("--public-url", metavar="URL", default=None,
                   help="address of the server as readers see it (http:// or https://); the base of the "
                        "API's viewerUrl links (default: serve.public_url in buildzr.yaml)")
    s.add_argument("--cors-origin", metavar="ORIGIN", action="append", default=None,
                   help="let this web origin read the API from a browser (repeatable; there is no wildcard; "
                        "default: serve.cors_origins in buildzr.yaml, which the option replaces)")
    s.set_defaults(workspace=None, k=None, text_color=None, no_viewer=False, out=None)
    return ap


# --- helpers ------------------------------------------------------------------------------------


def _fail(msg: str, code: int = 1) -> int:
    print(f"buildzr: error: {msg}", file=sys.stderr)
    return code


def _show(path: Path) -> str:
    """``path`` relative to the current folder when it is below it, else absolute."""
    try:
        return os.path.relpath(path) if Path(os.getcwd()) in path.parents else str(path)
    except ValueError:
        return str(path)


def _load_config(explicit: Optional[str]) -> Optional[Config]:
    """The config named by ``-c``, or the nearest ``buildzr.yaml``; ``None`` when there is none."""
    if explicit is not None:
        if not os.path.isfile(explicit):
            raise _Usage(f"config file not found: {explicit}")
        return cfgmod.load_config(explicit)
    found = cfgmod.find_config(os.getcwd())
    if found is None:
        return None
    return cfgmod.load_config(found)


def _counts(folder: str) -> str:
    """``13 elements, 6 relationships, 1 view`` of a built workspace, or ``""`` if it cannot be read."""
    try:
        with open(os.path.join(folder, "data", "index.json"), encoding="utf-8") as f:
            index = json.load(f)
        with open(os.path.join(folder, "data", index["model"]["file"]), encoding="utf-8") as f:
            model = json.load(f)
        parts = [(len(model["elements"]), "element"), (len(model["relationships"]), "relationship"),
                 (len(model["views"]), "view")]
        return ", ".join(f"{n} {w}{'' if n == 1 else 's'}" for n, w in parts)
    except (OSError, ValueError, KeyError, TypeError):
        return ""


def _short_hash(h: str) -> str:
    return h[:19] + "…"


def _settings(folder: str, info: dict[str, Any]) -> list[str]:
    """The build settings of a built workspace that are not the defaults: ``data only``, ``k 9``, ``text c4``."""
    defaults = BuildSettings()
    out = [] if os.path.isfile(os.path.join(folder, "index.html")) else ["data only"]
    if info.get("k", defaults.k) != defaults.k:
        out.append(f"k {info['k']}")
    if info.get("textColor", defaults.text_color) != defaults.text_color:
        out.append(f"text {info['textColor']}")
    return out


def _summary(folder: str, info: dict[str, Any]) -> str:
    counts = _counts(folder)
    parts = _settings(folder, info) + ([counts] if counts else [])
    return "; ".join(parts + ["modelHash " + _short_hash(info["modelHash"])])


class _BuildArgs:
    """Build settings after flag, file and default are merged.

    For each setting of a workspace: the option, then the ``build:`` of its entry in a ``workspaces:`` list, then the
    file's global ``build:``, then the built-in default. ``-w PATH`` replaces the file's ``workspaces:``, path or list.
    """

    def __init__(self, args: argparse.Namespace, cfg: Optional[Config]) -> None:
        env = os.environ
        self.cfg = cfg
        self.args = args
        base = cfg.build if cfg is not None else BuildSettings()
        if args.k is not None and args.k < 1:
            raise _Usage("--k: expected a whole number of at least 1")
        self.k: int = args.k if args.k is not None else base.k
        self.text_color: str = args.text_color if args.text_color is not None else base.text_color
        self.viewer: bool = base.viewer and not args.no_viewer
        here = cfg.root if cfg is not None else Path(os.getcwd())
        #: The ``workspaces:`` list of the file, when it has one and ``-w`` does not replace it.
        self.listed: Optional[list[cfgmod.ResolvedEntry]] = None
        if cfg is not None and args.workspace is None:
            self.listed = cfgmod.resolve_workspace_entries(cfg, env)
        configured = cfgmod.resolve_workspaces(cfg, env) if cfg is not None else None
        #: The workspaces folder of the project: what ``build.json`` records source paths against.
        self.folder: Path = configured if configured is not None else here / DEFAULT_WORKSPACES
        self.path: Path = Path(os.path.abspath(args.workspace)) if args.workspace is not None else self.folder
        if getattr(args, "out", None) is not None:
            self.out = Path(os.path.abspath(args.out))
        elif cfg is not None:
            self.out = cfgmod.resolve_build(cfg, env).out
        else:
            self.out = Path(os.path.abspath(DEFAULT_OUT))

    @property
    def root(self) -> str:
        """The folder source paths are relative to: the config's folder for a list; else the project's workspaces
        folder when PATH is in it."""
        if self.listed is not None:
            assert self.cfg is not None
            return str(self.cfg.root)
        if self.cfg is not None and self.cfg.workspace_list is not None:  # -w replaces the list
            return source_root(str(self.path))
        folder = self.folder if self.folder.is_dir() else self.folder.parent
        if self.path == folder or folder in self.path.parents:
            return str(folder)
        return source_root(str(self.path))

    @property
    def list_file(self) -> Optional[str]:
        """The config file whose ``workspaces:`` list is built, or ``None``."""
        return str(self.cfg.path) if self.listed is not None and self.cfg is not None else None

    @property
    def full(self) -> bool:
        """Whether this is a full build, which removes what it no longer builds: a list, or a folder."""
        return self.listed is not None or self.path.is_dir()

    def _entry(self, e: cfgmod.ResolvedEntry) -> Entry:
        a = self.args
        return Entry(str(e.path),
                     k=a.k if a.k is not None else e.k if e.k is not None else self.k,
                     text_color=a.text_color if a.text_color is not None else
                     e.text_color if e.text_color is not None else self.text_color,
                     viewer=False if a.no_viewer else e.viewer if e.viewer is not None else self.viewer,
                     helpers=source_root(str(e.path)))

    def entries(self) -> list[Entry]:
        """What to build, each file or folder with its options; checks that the paths exist.

        For a list, an entry that holds no Python file gets a warning line and is left out.
        """
        if self.listed is None:
            if not self.path.exists():
                raise _Usage(f"{_show(self.path)} not found; create the workspaces folder, pass -w PATH "
                             "or set workspaces: in buildzr.yaml")
            return [Entry(str(self.path), self.k, self.text_color, self.viewer)]
        assert self.cfg is not None
        out = []
        for e, files in zip(self.listed, cfgmod.workspace_files(self.cfg, self.listed)):
            if files:
                out.append(self._entry(e))
            else:
                print(f"buildzr: warning: {self.cfg.name}:{e.line}: {e.key}: {e.shown} holds no Python file "
                      "that can create a workspace; nothing is built from it", file=sys.stderr)
        return out

    @property
    def shown(self) -> str:
        """The input of the build, for messages."""
        if self.listed is not None and self.cfg is not None:
            return f"the workspaces: list of {_show(self.cfg.path)}"
        return _show(self.path)


# --- commands -----------------------------------------------------------------------------------


def _source_shown(folder: str, info: dict[str, Any]) -> str:
    """The model file of a built workspace as the user knows it (``workspaces/shop.py``), from its ``build.json``."""
    src = info.get("input", {}).get("file") if isinstance(info.get("input"), dict) else None
    rec = info.get("workspacesFolder")
    if not isinstance(src, str):
        return "an unknown model file"
    if not isinstance(rec, str):
        return src
    return _show(Path(os.path.normpath(os.path.join(os.path.dirname(folder), rec, src))))


def _loud(text: str) -> str:
    """``text`` in bold red when stderr is a terminal (and ``NO_COLOR`` is not set)."""
    if sys.stderr.isatty() and not os.environ.get("NO_COLOR"):
        return f"\033[1;31m{text}\033[0m"
    return text


def broken_block(name: str, folder: str, info: dict[str, Any], kept: bool = False) -> str:
    """The console block of a broken built workspace: name, file, stage, the first 10 errors.

    ``kept``: the broken result was not written (``serve --watch``), and the last good build is still served.
    """
    errors = [str(e) for e in info.get("errors") or []]
    lines = [_loud(f"buildzr: BROKEN: workspace {name} ({_source_shown(folder, info)}) "
                   f"failed at the {info.get('stage', 'unknown')} step")]
    lines += ["    " + e for e in errors[:10]]
    if len(errors) > 10:
        where = "" if kept else f" in {_show(Path(folder) / 'build.json')}"  # a kept result is in no file
        lines.append(f"    ... and {len(errors) - 10} more{where}")
    lines.append("  " + _loud("the last good build is still served; save a fix to rebuild" if kept else
                              "this workspace is broken; the viewer says so"))
    return "\n".join(lines)


def _report(result: BuildResult, root: Optional[str] = None) -> None:
    """One line per skipped file, built and removed workspace on stdout; failures and broken workspaces on stderr."""
    for e in result.empty:
        print(f"skipped {_show(Path(e))}: it creates no workspace")
    for b in result.built:
        print(f"built {_show(Path(b.folder))} ({_summary(b.folder, b.info)})")
    for r in result.removed:
        source = _show(Path(root) / r.source) if root is not None else r.source
        why = {"gone": f"its model file {source} is gone",
               "unlisted": f"its model file {source} is no longer in the workspaces: list"}.get(
            r.reason, f"{source} no longer creates it")
        print(f"removed {r.name}: {why}")
    sys.stdout.flush()
    for b in result.broken:
        print(broken_block(b.name, b.folder, b.info), file=sys.stderr)
    for b in result.kept:
        print(broken_block(b.name, b.folder, b.info, kept=True), file=sys.stderr)
    for f in result.failed:
        kept = "; nothing was written and the previous output is kept" if f.environment else ""
        print(f"buildzr: error: {f.where(_show(Path(f.path)))}: {f.message}{kept}", file=sys.stderr)


def _cmd_build(args: argparse.Namespace) -> int:
    cfg = _load_config(args.config)
    b = _BuildArgs(args, cfg)
    entries = b.entries()
    # A full build (a list, the workspaces folder, or -w FOLDER) removes what it no longer builds; -w FILE removes
    # nothing.
    result = build_all(entries, str(b.out), verbose=args.verbose, root=b.root, prune=b.full, listed=b.list_file) \
        if entries else BuildResult()
    _report(result, b.root)
    if result.failed or result.broken:
        return 1
    if not result.built:
        return _fail(f"no workspace found in {b.shown}: no .py file there creates a Workspace")
    return 0


def _cmd_export(args: argparse.Namespace) -> int:
    if args.workspace is not None and args.index is not None:
        raise _Usage("--workspace and --index cannot be used together")
    if args.index is not None and args.index < 0:
        raise _Usage("--index: expected 0 or a larger whole number")
    if not os.path.exists(args.file):
        raise _Usage(f"{args.file} not found")
    if os.path.isdir(args.file):
        raise _Usage(f"{args.file} is a folder; export takes one model file (buildzr build handles a whole folder)")
    formats = list(dict.fromkeys(args.format or ["json"]))
    return export_files.run(args.file, args.out, formats, args.layout, args.pretty, args.workspace, args.index)


def _node_problem() -> Optional[str]:
    """Why the layout cannot run here (no Node), or ``None``."""
    try:
        from buildzr.site.layout.elk import find_node
        find_node()
    except Exception:
        return ("building needs Node.js 18 or newer, which was not found; install it (or set BUILDZR_NODE), "
                "or serve what is already built with --no-build")
    return None


def _build_stale(args: argparse.Namespace, b: _BuildArgs, entries: list[Entry]) -> set[str]:
    """``serve``: build the workspaces that are missing or stale (all with ``--rebuild``); print what happened.

    With ``--watch``, a broken result does not replace an ok built workspace. Returns the names of the broken
    workspaces it reported.
    """
    if not entries:
        return set()
    todo = plan(entries, str(b.out), root=b.root, only_stale=not args.rebuild, listed=b.list_file)
    fresh = sorted(w.name for w in todo.fresh)
    if fresh:
        print("up to date: " + ", ".join(fresh))
    if not todo.todo:
        return set()
    problem = _node_problem()
    if problem:
        print(f"buildzr: error: {problem}", file=sys.stderr)
        return set()
    try:
        result = build_all(entries, str(b.out), verbose=args.verbose, only_stale=not args.rebuild, root=b.root,
                           listed=b.list_file, keep_good=args.watch)
    except BuildError as e:
        print(f"buildzr: error: {e}", file=sys.stderr)
        return set()
    _report(result)
    return {w.name for w in result.broken}


def _changed_shown(files: set[str]) -> str:
    shown = [_show(Path(f)) for f in sorted(files)]
    return ", ".join(shown[:3]) + (f" and {len(shown) - 3} more" if len(shown) > 3 else "")


def _rebuild(args: argparse.Namespace, b: _BuildArgs, entries: list[Entry], files: set[str]) -> None:
    """``serve --watch``: build what the change of ``files`` made stale, as ``build`` does, but keep the good builds.

    It prints what happened and never raises (but for Ctrl+C): the watch goes on after any failure.
    """
    print(f"changed: {_changed_shown(files)}", flush=True)  # before what the model file prints
    config = str(b.cfg.path) if b.cfg is not None else None
    if config is not None and config in files:
        print(f"buildzr: warning: {_show(Path(config))} changed; restart buildzr serve --watch to use its new settings",
              file=sys.stderr)
        if files == {config}:
            sys.stdout.flush()
            return
    try:
        result = build_all(entries, str(b.out), verbose=args.verbose, only_stale=True, root=b.root, prune=b.full,
                           listed=b.list_file, keep_good=True)
    except BuildError as e:
        print(f"buildzr: error: {e}", file=sys.stderr)
        return
    except Exception as e:  # a bug or the disk: say so and keep watching
        print(f"buildzr: error: the rebuild failed: {type(e).__name__}: {e}", file=sys.stderr)
        return
    _report(result, b.root)
    changed = sorted({w.name for w in result.built + result.broken})
    if changed:
        print("reloading the open viewers of " + ", ".join(changed))
    elif not (result.kept or result.failed or result.removed or result.empty):
        print("nothing to rebuild: every built workspace is up to date")
    sys.stdout.flush()


def _watcher(args: argparse.Namespace, b: _BuildArgs, entries: list[Entry]) -> watch.Watcher:
    """``serve --watch``: the watcher of the model files of ``entries``, their helpers and ``buildzr.yaml``."""
    config = str(b.cfg.path) if b.cfg is not None else None

    def scan() -> watch.Signature:  # a file added to a watched folder counts from the next scan
        return watch.signature(watch.watched_files(entries, b.root, config, skip=[str(b.out)]))
    return watch.Watcher(scan, lambda changed: _rebuild(args, b, entries, changed))


def _serve_settings(args: argparse.Namespace, cfg: Optional[Config]) -> tuple[str, int, Optional[str], list[str]]:
    """Host, port, public URL and CORS origins: each option, else ``serve:`` in ``buildzr.yaml``, else the default.

    ``--cors-origin`` replaces the file's list; it does not add to it.
    """
    try:
        public_url = normalise_public_url(args.public_url) if args.public_url is not None else None
    except ValueError as e:
        raise _Usage(f"--public-url: {e}") from None
    try:
        origins = list(dict.fromkeys(normalise_origin(o) for o in args.cors_origin)) \
            if args.cors_origin is not None else None
    except ValueError as e:
        raise _Usage(f"--cors-origin: {e}") from None
    if args.port is not None and not 1 <= args.port <= 65535:
        raise _Usage(f"--port: {PORT_MESSAGE}, got {args.port}")
    if args.host is not None and args.host == "":
        raise _Usage("--host: expected a host name or address, got empty text")
    file = cfgmod.resolve_serve(cfg, os.environ) if cfg is not None else None
    host = args.host if args.host is not None else (file.host if file and file.host is not None else DEFAULT_HOST)
    port = args.port if args.port is not None else (file.port if file and file.port is not None else DEFAULT_PORT)
    if public_url is None and file is not None:
        public_url = file.public_url
    if origins is None:
        origins = file.cors_origins if file is not None and file.cors_origins is not None else []
    return host, port, public_url, origins


#: The ``serve`` options that have no meaning for ``--example``, which neither builds nor reads a config.
_EXAMPLE_CONFLICTS = (("path", "PATH"), ("no_build", "--no-build"), ("rebuild", "--rebuild"), ("config", "-c/--config"),
                      ("verbose", "-v/--verbose"), ("watch", "--watch"))


def _cmd_serve_example(args: argparse.Namespace) -> int:
    """``serve --example``: the bundled example, copied to a temporary folder that is removed on exit."""
    for dest, shown in _EXAMPLE_CONFLICTS:
        if getattr(args, dest):
            raise _Usage(f"--example serves the bundled example, so it cannot be used with {shown}")
    host, port, public_url, origins = _serve_settings(args, None)  # no buildzr.yaml: the folder it is run in is ignored
    with tempfile.TemporaryDirectory(prefix="buildzr-example-") as tmp:
        try:
            stage_example(tmp)
        except ExampleError as e:
            return _fail(str(e))
        previous = signal.signal(signal.SIGTERM, signal.default_int_handler)  # stop like Ctrl+C, so tmp is removed
        try:
            serve(tmp, host, port, public_url, origins, shown="the bundled example")
        except OSError as e:
            return _fail(f"cannot serve on {host}:{port}: {e.strerror or e}")
        finally:
            signal.signal(signal.SIGTERM, previous)
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    if args.example:
        return _cmd_serve_example(args)
    cfg = _load_config(args.config)
    host, port, public_url, origins = _serve_settings(args, cfg)
    if args.no_build and args.rebuild:
        raise _Usage("--no-build and --rebuild cannot be used together")
    if args.no_build and args.watch:
        raise _Usage("--no-build and --watch cannot be used together: --watch rebuilds after each change")
    if args.path is not None and not os.path.exists(args.path):
        raise _Usage(f"{args.path} not found")
    watcher: Optional[watch.Watcher] = None
    if args.path is not None and os.path.isdir(args.path) and holds_built_workspaces(args.path):
        for flag, dest in (("--rebuild", "rebuild"), ("--watch", "watch")):
            if getattr(args, dest):
                raise _Usage(f"{args.path} holds built workspaces, which are served as they are; {flag} needs "
                             "the workspaces folder or a .py file")
        directory = args.path
        reported: set[str] = set()
    else:
        args.workspace = args.path
        b = _BuildArgs(args, cfg)
        directory = str(b.out)
        reported = set()
        if not args.no_build:
            if b.listed is None and not b.path.exists():
                raise _Usage(f"{_show(b.path)} not found; create the workspaces folder, pass PATH, set workspaces: "
                             f"in buildzr.yaml, or serve {_show(b.out)} as it is with --no-build")
            entries = b.entries()
            if args.watch:
                watcher = _watcher(args, b, entries)
                last = watcher.scan()  # before the build: a change made while it runs is not missed
            reported = _build_stale(args, b, entries)
    served = Catalog(directory).entries()
    if not served and watcher is None:
        return _fail(f"nothing to serve: {_show(Path(os.path.abspath(directory)))} holds no built workspace")
    sys.stdout.flush()  # "up to date: ..." before the blocks, also when both streams go to one pipe
    for e in served.values():
        if e.info.get("status") == "broken" and e.name not in reported:
            print(broken_block(e.name, e.folder, e.info), file=sys.stderr)
    if watcher is None:
        try:
            serve(directory, host, port, public_url, origins, shown=_show(Path(os.path.abspath(directory))))
        except OSError as e:
            return _fail(f"cannot serve on {host}:{port}: {e.strerror or e}")
        return 0
    if not served:
        print(f"nothing built yet in {_show(Path(os.path.abspath(directory)))}; waiting for a model file to change")
    os.makedirs(directory, exist_ok=True)

    def watching() -> None:
        print(f"Watching {b.shown} for changes")
        sys.stdout.flush()
        assert watcher is not None
        watcher.run(last)
    main_thread = threading.current_thread() is threading.main_thread()  # only it can set a signal handler
    previous = signal.signal(signal.SIGTERM, signal.default_int_handler) if main_thread else None  # stop like Ctrl+C
    try:
        serve(directory, host, port, public_url, origins, shown=_show(Path(os.path.abspath(directory))), watch=watching)
    except OSError as e:
        return _fail(f"cannot serve on {host}:{port}: {e.strerror or e}")
    finally:
        if main_thread:
            signal.signal(signal.SIGTERM, previous)
    return 0


def main(argv: Optional[Iterable[str]] = None) -> int:
    ap = _parser()
    try:
        try:
            args = ap.parse_args(list(argv) if argv is not None else None)
        except SystemExit as e:  # --help and --version (0)
            return int(e.code or 0)
        if args.cmd == "build":
            return _cmd_build(args)
        if args.cmd == "export":
            return _cmd_export(args)
        return _cmd_serve(args)
    except _Usage as e:
        return _fail(str(e), 2)
    except ConfigError as e:
        print(str(e), file=sys.stderr)  # the loader already formatted every line
        return 2
    except BuildError as e:
        return _fail(str(e), 1)


if __name__ == "__main__":
    sys.exit(main())
